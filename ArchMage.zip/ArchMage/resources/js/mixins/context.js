const _rodeType = [
    {"type": 0, "number": '30'},
    {"type": 1, "number": '90'},
    {"type": 2, "number": '150'},
];
  
export default {
  
    data() {
      return {
        rodeType: _rodeType,
      }
    },
    methods: {
        rodeTypeNumber(type) {
            return this.rodeType.find(item => item.type == type).number;
        },
    }
}
  