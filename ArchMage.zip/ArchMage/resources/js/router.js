import Vue from 'vue';
import VueRouter from 'vue-router';

import Navigation from './components/Navigation.vue'
const Map = () => import(/* webpackChunkName: 'chunk/Archmage' */ './pages/BigMap.vue')
Vue.use(VueRouter);

// パスとコンポーネントのマッピング
const routes = [
  {
    path: '/',
    redirect: '/map'
  },
  { path: '/nav',
    component: Navigation,
    children: [
      {
        path: '/map',
        component: Map,
      },
    ]
  },

];

// VueRouterインスタンスを作成する
const router = new VueRouter({
  routes
});

// VueRouterインスタンスをエクスポートする
export default router