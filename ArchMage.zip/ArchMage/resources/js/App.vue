<template>
  <div>
    <main class="main-class">
        <RouterView />
    </main>
  </div>
</template>
