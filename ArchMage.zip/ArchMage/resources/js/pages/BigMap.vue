<template>
    <el-container>
        <!-- <el-main style="background-color: #5fc9d7;"> -->
        <el-main>
            <!-- 资源板块 -->
            <div v-if="plateList.length > 0">
                <div :style="'position: absolute;top:'+(positionMiddleTop+92.5)+'px;left:'+(positionMiddleLeft-138)+'px;'">
                    <div v-for="plate in plateList[0]" :key="'plate_' + plate.id">
                        <MapPlate :plate="plate"></MapPlate>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+(positionMiddleTop+66)+'px;left:'+(positionMiddleLeft-92)+'px;'">
                    <div v-for="plate in plateList[1]" :key="'plate_' + plate.id">
                        <MapPlate :plate="plate"></MapPlate>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+(positionMiddleTop+39.5)+'px;left:'+(positionMiddleLeft-46)+'px;'">
                    <div v-for="plate in plateList[2]" :key="'plate_' + plate.id">
                        <MapPlate :plate="plate"></MapPlate>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+(positionMiddleTop+13)+'px;left:'+positionMiddleLeft+'px;'">
                    <div v-for="plate in plateList[3]" :key="'plate_' + plate.id">
                        <MapPlate :plate="plate"></MapPlate>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+(positionMiddleTop+39.5)+'px;left:'+(positionMiddleLeft+46)+'px;'">
                    <div v-for="plate in plateList[4]" :key="'plate_' + plate.id">
                        <MapPlate :plate="plate"></MapPlate>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+(positionMiddleTop+66)+'px;left:'+(positionMiddleLeft+92)+'px;'">
                    <div v-for="plate in plateList[5]" :key="'plate_' + plate.id">
                        <MapPlate :plate="plate"></MapPlate>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+(positionMiddleTop+92.5)+'px;left:'+(positionMiddleLeft+138)+'px;'">
                    <div v-for="plate in plateList[6]" :key="'plate_' + plate.id">
                        <MapPlate :plate="plate"></MapPlate>
                    </div>
                </div>
            </div>

            <!-- 房屋 -->
            <div v-if="houseList.length > 0">
                <div :style="'position: absolute;top:'+(positionMiddleTop+105)+'px;left:'+(positionMiddleLeft-158)+'px;'">
                    <div v-for="house in houseList[0]" :key="'house_' + house.id">
                        <House :house="house"></House>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+(positionMiddleTop+78)+'px;left:'+(positionMiddleLeft-144)+'px;'">
                    <div v-for="house in houseList[1]" :key="'house_' + house.id">
                        <House :house="house"></House>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+(positionMiddleTop+78)+'px;left:'+(positionMiddleLeft-112)+'px;'">
                    <div v-for="house in houseList[2]" :key="'house_' + house.id">
                        <House :house="house"></House>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+(positionMiddleTop+53)+'px;left:'+(positionMiddleLeft-98)+'px;'">
                    <div v-for="house in houseList[3]" :key="'house_' + house.id">
                        <House :house="house"></House>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+(positionMiddleTop+53)+'px;left:'+(positionMiddleLeft-66)+'px;'">
                    <div v-for="house in houseList[4]" :key="'house_' + house.id">
                        <House :house="house"></House>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+(positionMiddleTop+26)+'px;left:'+(positionMiddleLeft-52)+'px;'">
                    <div v-for="house in houseList[5]" :key="'house_' + house.id">
                        <House :house="house"></House>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+(positionMiddleTop+26)+'px;left:'+(positionMiddleLeft-19)+'px;'">
                   <div v-for="house in houseList[6]" :key="'house_' + house.id">
                        <House :house="house"></House>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+positionMiddleTop+'px;left:'+(positionMiddleLeft-5)+'px;'">
                    <div v-for="house in houseList[7]" :key="'house_' + house.id">
                        <House :house="house"></House>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+positionMiddleTop+'px;left:'+(positionMiddleLeft+25)+'px;'">
                    <div v-for="house in houseList[8]" :key="'house_' + house.id">
                        <House :house="house"></House>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+(positionMiddleTop+26)+'px;left:'+(positionMiddleLeft+39)+'px;'">
                    <div v-for="house in houseList[9]" :key="'house_' + house.id">
                        <House :house="house"></House>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+(positionMiddleTop+26)+'px;left:'+(positionMiddleLeft+71)+'px;'">
                    <div v-for="house in houseList[10]" :key="'house_' + house.id">
                        <House :house="house"></House>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+(positionMiddleTop+53)+'px;left:'+(positionMiddleLeft+85)+'px;'">
                    <div v-for="house in houseList[11]" :key="'house_' + house.id">
                        <House :house="house"></House>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+(positionMiddleTop+53)+'px;left:'+(positionMiddleLeft+117)+'px;'">
                    <div v-for="house in houseList[12]" :key="'house_' + house.id">
                        <House :house="house"></House>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+(positionMiddleTop+78)+'px;left:'+(positionMiddleLeft+130)+'px;'">
                    <div v-for="house in houseList[13]" :key="'house_' + house.id">
                        <House :house="house"></House>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+(positionMiddleTop+78)+'px;left:'+(positionMiddleLeft+163)+'px;'">
                    <div v-for="house in houseList[14]" :key="'house_' + house.id">
                        <House :house="house"></House>
                    </div>
                </div>
                <div :style="'position: absolute;top:'+(positionMiddleTop+105)+'px;left:'+(positionMiddleLeft+176)+'px;'">
                    <div v-for="house in houseList[15]" :key="'house_' + house.id">
                        <House :house="house"></House>
                    </div>
                </div>
            </div>

            <!-- 道路 -->
            <div v-if="roadList.length > 0">
                <!-- 30度道路 -->
                <div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+98)+'px;left:'+(positionMiddleLeft-149)+'px;'">
                        <div v-for="road in roadList[0][0]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+70)+'px;left:'+(positionMiddleLeft-103)+'px;'">
                        <div v-for="road in roadList[0][1]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+44)+'px;left:'+(positionMiddleLeft-57)+'px;'">
                        <div v-for="road in roadList[0][2]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+18)+'px;left:'+(positionMiddleLeft-11)+'px;'">
                        <div v-for="road in roadList[0][3]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+44)+'px;left:'+(positionMiddleLeft+35)+'px;'">
                        <div v-for="road in roadList[0][4]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+70)+'px;left:'+(positionMiddleLeft+81)+'px;'">
                        <div v-for="road in roadList[0][5]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+96)+'px;left:'+(positionMiddleLeft+127)+'px;'">
                        <div v-for="road in roadList[0][6]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+122)+'px;left:'+(positionMiddleLeft+173)+'px;'">
                        <div v-for="road in roadList[0][7]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                </div>

                <!-- 90度道路 -->
                <div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+84)+'px;left:'+(positionMiddleLeft-126)+'px;'">
                        <div v-for="road in roadList[1][0]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+58)+'px;left:'+(positionMiddleLeft-80)+'px;'">
                        <div v-for="road in roadList[1][1]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+31)+'px;left:'+(positionMiddleLeft-34)+'px;'">
                        <div v-for="road in roadList[1][2]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+5)+'px;left:'+(positionMiddleLeft+12)+'px;'">
                        <div v-for="road in roadList[1][3]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+31)+'px;left:'+(positionMiddleLeft+58)+'px;'">
                        <div v-for="road in roadList[1][4]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+58)+'px;left:'+(positionMiddleLeft+104)+'px;'">
                        <div v-for="road in roadList[1][5]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+84)+'px;left:'+(positionMiddleLeft+150)+'px;'">
                        <div v-for="road in roadList[1][6]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                </div>

                <!-- 150度道路 -->
                <div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+122)+'px;left:'+(positionMiddleLeft-149)+'px;'">
                        <div v-for="road in roadList[2][0]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+97)+'px;left:'+(positionMiddleLeft-103)+'px;'">
                        <div v-for="road in roadList[2][1]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+70)+'px;left:'+(positionMiddleLeft-57)+'px;'">
                        <div v-for="road in roadList[2][2]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+44)+'px;left:'+(positionMiddleLeft-11)+'px;'">
                        <div v-for="road in roadList[2][3]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+18)+'px;left:'+(positionMiddleLeft+35)+'px;'">
                        <div v-for="road in roadList[2][4]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+44)+'px;left:'+(positionMiddleLeft+81)+'px;'">
                        <div v-for="road in roadList[2][5]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+70)+'px;left:'+(positionMiddleLeft+127)+'px;'">
                        <div v-for="road in roadList[2][6]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                    <div :style="'height: 10px;position: absolute;top:'+(positionMiddleTop+97)+'px;left:'+(positionMiddleLeft+173)+'px;'">
                        <div v-for="road in roadList[2][7]" :key="'road_' + road.id">
                            <Road :road="road"></Road>
                        </div>
                    </div>
                </div>
                
                
            </div>

            <!-- 港口 -->
            <div v-if="portList.length > 0">
                <div v-for="(port,portIindex) in portList" :key="'port_' + port.id">
                    <Port :port="port" :index="portIindex"></Port>
                </div>
            </div>
            <div style="position: relative;
    top: 500px;">
                <el-button @click="resetMap()">ResetMap</el-button>
                <el-button @click="getPlateList()">GetPlateList</el-button>
            </div>
        </el-main>
    </el-container>
</template>
<script>
    import MapPlate from "../components/BigMapPlate.vue"
    import House from "../components/House.vue"
    import Road from "../components/Road.vue"
    import Port from "../components/Port.vue"
    export default {
        components:{
            MapPlate,
            House,
            Road,
            Port,
        },
        data () {
            return {
                positionMiddleLeft:150,
                positionMiddleTop:50,
                plateList:[],
                houseList:[],
                roadList:[],
                portList:[],
                mapId:10,
                userId:1,
            }
        },
        methods: {
            resetMap(){
                axios.post("/api/resetMap")
                    .then(res=>{
                        this.mapId = res.data.mapId;
                    }).catch(err=>{
                        console.log(err);
                    });
            },
            getPlateList(){
                axios.get("/api/getMapPlateList",{
                    params:{
                        mapId:this.mapId,
                    }
                }).then(res=>{
                    this.plateList = res.data.plateList;
                    this.houseList = res.data.houseList;
                    this.roadList = res.data.roadList;
                    this.portList = res.data.portList;
                }).catch(err=>{
                    console.log(err);
                });
            },
        },
        mounted () {
            this.positionMiddleLeft = window.innerWidth/2 - 16;
            let bodyItem = document.getElementsByClassName('el-main')[0]
            bodyItem.style.height = window.innerHeight + "px";
            // this.getPlateList();
        }
    }
</script>
<style>
</style>
