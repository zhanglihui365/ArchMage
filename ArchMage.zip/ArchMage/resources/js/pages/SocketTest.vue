<template>
    <div></div>
</template>
<script>
    import SocketIO from 'socket.io-client';
    export default {
        data () {
            return {
                user: {
                room: '',
                id: '',
                name: '',
                },
                userSelf: {},
                socket: null,
            }
        },
        methods: {
            join: function () {
                this.user.room = 'group_' + this.member.groupId;
                this.socket.emit("join", this.user);
            },
            leave: function () {
                this.socket.emit("leave", this.user.room);
            },
            send: function (data) {
                //   "msg" ,  メッセージ
                //   "nickname" ,  ユーザー名
                //   "id" ,  ユーザーID
                //   "mid" ,  メッセージ変更の時はメッセージID
                //   "file" ,  添付ファイル名
                //   "timeStamp" ,  タイムスタンプ Long
                //   "maxid" メッセージの最大ID
                let msg = {
                msg: this.sendMsg,
                gid: this.member.groupId,
                nickname: this.user.name,
                id: this.user.id,
                maxid: data.id,
                file: data.file_name,
                };
                console.log(msg);
                this.socket.emit("chat.send.message", msg);
                this.sendMsg = '';
            },
            clearGroup(){
                axios.get("/api/clearGroup", {
                params: {
                    groupId: this.member.groupId,
                }
                }).then(res => {
                }).catch(err => {
                });
            },
            doConnect(){
                axios.get("/api/getUser")
                .then(res => {
                    this.userSelf = res.data;
                    this.user = {
                    room: '',
                    id: this.userSelf.id,
                    name: this.userSelf.name,
                    };
                    const socketUri = 'http://10.113.8.128:3002';
                    const attempts = 5;
                    let self = this;
                    if (socketUri) {
                    this.socket = SocketIO(socketUri, {
                        'reconnection': true,
                        'reconnectionDelay': 1000,
                        'reconnectionDelayMax': 5000,
                        'reconnectionAttempts': attempts ? attempts : 5
                    });
                    let $this = this;
                    this.socket.on('chat.message', function (chatMsg) {
                        console.log(chatMsg);
                        //msgObj:{"msg":"123","gid":5,"id":1}
                        let msgObj = JSON.parse(chatMsg);
                        let date = new Date();
                        let chatItem = {
                        created_at: date.getHours() + ':' + date.getMinutes(),
                        file_name: msgObj.file,
                        from_user_id: self.member.id,
                        group_id: self.member.groupId,
                        id: msgObj.maxid,
                        message: msgObj.msg,
                        updated_at: date.getHours() + ':' + date.getMinutes(),
                        user: {
                            id: self.userSelf.id,
                            name: self.userSelf.name,
                            file: self.userSelf.file,
                            enterprise: {
                            name: self.userSelf.enterprise.name,
                            }
                        }
                        };
                        console.log(chatItem);
                        self.chatLists.push(chatItem);
                    });
                    this.socket.on('chat.users', function (nicknames) {
                    })
                    }
                }).catch(err => {
                });
            },

            //伪方法
            sendMsg(){
                this.send(res.data.params);
            },
            fetch(){
                this.join();
            },
        },
        mounted () {
        },
        destroyed() {
            if (this.socket) {
                this.socket.close();
            }
        },
    }
</script>
<style>
</style>
