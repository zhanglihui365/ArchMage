<template>
    <el-container>
        <div v-show="showPageNumber == 1">
            <div style="position: absolute;top:150px;left: 50px;">
                <MapPlate></MapPlate>
                <MapPlate></MapPlate>
                <MapPlate></MapPlate>
                <MapPlate></MapPlate>
            </div>
            <div style="position: absolute;top:116px;left: 111px;">
                <MapPlate></MapPlate>
                <MapPlate></MapPlate>
                <MapPlate></MapPlate>
                <MapPlate></MapPlate>
                <MapPlate></MapPlate>
            </div>
            <div style="position: absolute;top:82px;left: 172px;">
                <MapPlate></MapPlate>
                <MapPlate></MapPlate>
                <MapPlate></MapPlate>
                <MapPlate></MapPlate>
                <MapPlate></MapPlate>
                <MapPlate></MapPlate>
            </div>
            <div style="position: absolute;top:116px;left: 233px;">
                <MapPlate></MapPlate>
                <MapPlate></MapPlate>
                <MapPlate></MapPlate>
                <MapPlate></MapPlate>
                <MapPlate></MapPlate>
            </div>
            <div style="position: absolute;top:150px;left: 294px;">
                <MapPlate></MapPlate>
                <MapPlate></MapPlate>
                <MapPlate></MapPlate>
                <MapPlate></MapPlate>
            </div>
        </div>
    </el-container>
</template>
<script>
    import MapPlate from "../components/MapPlate.vue"
    export default {
        components:{
            MapPlate,
        },
        data () {
            return {
                positionTop:'200px;',
                positionHeight:100,
                showPageNumber:1,
            }
        },
        methods: {
            
        },
        mounted () {
            // this.positionTop = (window.innerHeight/2 - 2*50) + 'px;';
        }
    }
</script>
<style>

</style>
