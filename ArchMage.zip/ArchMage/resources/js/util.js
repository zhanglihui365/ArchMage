const _portPositon = [
    {"index": 0, "left": -11, "top": 213, "transform": 90},
    {"index": 1, "left": 28, "top": 92, "transform": 150},
    {"index": 2, "left": 121, "top": 39, "transform": 150},
    {"index": 3, "left": 201, "top": 39, "transform": 210},
    {"index": 4, "left": 294, "top": 92, "transform": 210},
    {"index": 5, "left": 333, "top": 161, "transform": 270},
    {"index": 6, "left": 293, "top": 283, "transform": 330},
    {"index": 7, "left": 201, "top": 335, "transform": 330},
    {"index": 8, "left": 121, "top": 335, "transform": 30},
    {"index": 9, "left": 29, "top": 283, "transform": 30},
];
  
export default {

    data() {
        return {
            portPositon: _portPositon,
        }
    },
    methods: {
        getPortPositonItem(index) {
            return this.portPositon.find(item => item.index == index);
        },
    }
}
  