<template>
    <div :style="'opacity:'+(road.userId ? '1':'0')" @click="createNewRoad()">
    <!-- <div @click="createNewRoad"> -->
        <div class="road" :style="'transform: rotate('+this.rodeTypeNumber(road.type)+'deg);color:'+road.color"></div>
    </div>
</template>
<script>
    import Context from '../mixins/context.js'
    export default {
        props: ['road'],
        mixins: [
            Context,
        ],
        data () {
            return {
                userId:1,
            }
        },
        methods: {
            createNewRoad(){
                if(this.road.userId == 0){
                    axios.post("/api/createNewRoad",{
                        road:this.road, 
                        userId:this.userId,
                    }).then(res=>{
                        if(res.data.errMsg === ''){
                            this.road = res.data.road;
                        }else{
                            alert(res.data.errMsg);
                        }
                    }).catch(err=>{
                        console.log(err);
                    });
                }
            },
        },
        mounted () {
        }
    }
</script>
<style>
    .road {
        width: 6px;
        height: 16px;
        background-color: red;
        margin-bottom:36.5px;
        z-index: 1;
    }
</style>
