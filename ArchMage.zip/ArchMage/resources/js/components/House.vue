<template>
    <div :style="'opacity:'+(house.userId ? '1':'0')" @click="createNewHouse()">
    <!-- <div> -->
        <div class="house" v-show="house.type == 1">
            <div class='house-top' :style="'border-color:transparent transparent '+house.color+' transparent'"></div>
            <div class='house-bottom' :style="'background-color:'+house.color"></div>
        </div>
        <div class="house" v-show="house.type == 2">
            <div class='house-top' :style="'border-color:transparent transparent '+house.color+' transparent'"></div>
            <div class='house-bottom' :style="'background-color:'+house.color"></div>
        </div>
    </div>
</template>
<script>
    export default {
        props: ['house'],
        data () {
            return {
                userId:1,
            }
        },
        methods: {
            createNewHouse(){
                if(this.house.userId == 0){
                    axios.post("/api/createNewHouse",{
                        house:this.house,
                        userId:this.userId,
                    }).then(res=>{
                        if(res.data.errMsg === ''){
                            this.house = res.data.house;
                        }else{
                            alert(res.data.errMsg);
                        }
                    }).catch(err=>{
                        console.log(err);
                    });
                }
            },
        },
        mounted () {
            
        }
    }
</script>
<style>
    .house {
        margin-bottom:31px;
        z-index: 2;
    }
    .house-top {
        content: '';
        display: block;
        width: 0;
        height: 0;
        border-width: 6px 6px;
        border-style: solid;
        border-color: transparent transparent black transparent;
        position: relative;
        left: 0px;
        top: 0px;
        z-index: 2;
    }
    .house-bottom {
        width: 10px;
        height: 9px;
        background-color: black;
        position: relative;
        left: 1px;
        top: -1px;
        z-index: 2;
    }
</style>
