<template>
    <div class="port" :style="'left:'+portSettingItem.left+'px;top:'+portSettingItem.top+'px;transform: rotate('+portSettingItem.transform+'deg);'">
        <div class="portBody"></div>
        <img class="portImage" :src="'images/type'+port.resourcesType+'.jpeg'">
    </div>
</template>
<script>
    import Util from '../util.js'
    export default {
        props: ['port','index'],
        mixins: [ Util ],
        data () {
            return {
                userId:1,
                portSettingItem:[],
            }
        },
        methods: {
        },
        mounted () {
            this.portSettingItem = this.getPortPositonItem(this.index);
        }
    }
</script>
<style>
    .port {
        z-index: -1;
        position: absolute;
    }
    .portBody{
        content: '';
        display: block;
        width: 0;
        height: 0;
        border-width: 15px 26px;
        border-style: solid;
        border-color: transparent transparent rgb(41, 22, 128) transparent;
    }
    .portImage {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        position: relative;
        left: 11px;
    }
</style>
