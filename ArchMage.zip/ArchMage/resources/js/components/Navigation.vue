<template>
  <div>
    <!--nav-wrapper-->
    <div class="nav-wrapper">
      <div class="logo"></div>
      <nav>
        <ul>
          <!--<li><router-link to="/dashboard" class="dashboard">ダッシュボード</router-link></li>-->
          <!-- <li @click="browse('notice')"><router-link to="/notice"  class="notice">お知らせ</router-link></li>
          <li @click="browse('contract')"><router-link to="/contract"  class="contract">契約者</router-link></li>
          <li @click="browse('worker')"><router-link to="/worker" class=" worker">職人</router-link></li>
          <li @click="browse('report')"><router-link to="/adminReport" class="report">通報</router-link></li> -->
        </ul>
      </nav>
    </div>
    <!--/nav-wrapper-->
    <RouterView id="app" class="app"/>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        user: {},
      }
    },
    methods: {
      
    },
    created() {
    }
  }
</script>
