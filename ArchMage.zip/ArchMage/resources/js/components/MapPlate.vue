<template>
    <div class='plate'>
        <div class="circle">
            <div class="number">
                {{ number }}
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data () {
            return {
                number:6,
            }
        },
        methods: {
            
        },
        mounted () {
            
        }
    }
</script>
<style>
    .plate {
        position: relative;
        width: 40px;
        height: 66px;
        /* margin: 50px auto; */
        background-color: #419318;
        border: solid 1px #e5e5e5;
        z-index:0;
    }
    .plate:before {
        content: '';
        display: block;
        position: absolute;
        width: 0;
        height: 0;
        right:40px;
        border-width: 33px 20px;
        border-style: solid;
        border-color: transparent #419318 transparent transparent;
    }
    .plate:after {
        content: '';
        display: block;
        position: absolute;
        width: 0;
        height: 0;
        left:40px;
        border-width: 33px 20px;
        border-style: solid;
        border-color: transparent transparent transparent #419318;
        top:0;
    }
    .circle {
        z-index:1;
        background-color: #f8ead5;
        height: 30px;
        width: 30px;
        border-radius: 50%;
        position: relative;
        top: 17px;
        left: 5px;
    }
    .number {
        font-size: 20px;
        font-weight: bold;
        text-align: center;
    }
</style>
