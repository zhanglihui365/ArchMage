<template>
    <div class='plate' :style="'background: url(../images/type'+plate.resourcesType+'.jpeg) 50% 50% no-repeat;'">
        <div class='left' :class="'type'+plate.resourcesType"></div>
        <div class='right' :class="'type'+plate.resourcesType"></div>
        <div class='circle' v-show="plate.number != 7">
            <div class='number' :style="'color:' + (plate.number == 6 || plate.number == 8 ? '#a70808' : 'black')">
                {{ plate.number }}
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        props: ['plate'],
        data () {
            return {
                number:6,
            }
        },
        methods: {
            
        },
        mounted () {
            
        }
    }
</script>
<style>
    .circle {
        z-index: 1;
        background-color: #f8ead5;
        height: 20px;
        width: 20px;
        border-radius: 50%;
        position: relative;
        top: 17px;
        left: 5px;
    }
    .number {
        font-size: 14px;
        font-weight: bold;
        text-align: center;
    }
</style>
