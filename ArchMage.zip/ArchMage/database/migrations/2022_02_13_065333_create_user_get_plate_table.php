<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUserGetPlateTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_get_plate', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('mapId');
            $table->integer('plateId');
            $table->integer('houseId');
            $table->integer('userId');
            $table->integer('portId');
            $table->tinyInteger('resourcesType')->comment("资源类型[1:羊、2:麦子、3:木材、4:砖块、5:矿石]");
            $table->tinyInteger('plateType')->comment("板块类型[0:沙漠、1:资源、2:港口]");
            $table->tinyInteger('haveRobber')->comment("板块上是否有强盗[0:没有、1:有]");
            $table->integer('number')->comment("获得资源的色子点数");
            $table->tinyInteger('resourcesCount')->comment("获得资源个数");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_get_plate');
    }
}
