<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMapHouseTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('map_house', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('mapId');
            $table->integer('userId')->comment('拥有者');
            $table->string('nearPortId')->comment('临近港口id');
            $table->tinyInteger('type')->comment('房屋类型:1、小房子 2、大房子');
            $table->tinyInteger('resourcesNumber')->comment('对应获取资源数量');
            $table->string('color')->comment('颜色');
            $table->tinyInteger('arrIndexX')->comment('房屋所在位置,数组中第几列(从零开始计数)');
            $table->tinyInteger('arrIndexY')->comment('房屋所在位置,数组中某列的第几个元素(从零开始计数)');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('map_house');
    }
}
