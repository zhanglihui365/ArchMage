<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMapPlateTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('map_plate', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('mapId');
            $table->tinyInteger('resourcesType')->comment("资源类型[0:沙漠、1:羊、2:麦子、3:木材、4:砖块、5:矿石]");
            $table->tinyInteger('plateType')->comment("板块类型[0:沙漠、1:资源、2:港口]");
            $table->integer('number')->comment("获得资源的色子点数");
            $table->tinyInteger('arrIndexX')->comment('资源板块所在位置,数组中第几列(从零开始计数)');
            $table->tinyInteger('arrIndexY')->comment('资源板块所在位置,数组中某列的第几个元素(从零开始计数)');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('map_plate');
    }
}
