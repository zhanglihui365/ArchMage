<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMapPortTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('map_port', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('mapId');
            $table->integer('userId')->comment('拥有者');
            $table->tinyInteger('resourcesType')->comment("港口资源类型[1:羊、2:麦子、3:木材、4:砖块、5:矿石]");
            $table->tinyInteger('resourcesNumber')->comment('兑换比例');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('map_port');
    }
}
