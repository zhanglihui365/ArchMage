<?php

namespace App\Models;

use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\SoftDeletes;

class UserGetPlate extends Model
{
    protected $table = "user_get_plate";
    protected $primaryKey = "id";
    protected $guarded = ['id'];


}
