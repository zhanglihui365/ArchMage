<?php

namespace App\Models;

use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\SoftDeletes;

class MapRoad extends Model
{
    protected $table = "map_road";
    protected $primaryKey = "id";
    protected $guarded = ['id'];


}
