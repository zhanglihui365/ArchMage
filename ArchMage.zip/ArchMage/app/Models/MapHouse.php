<?php

namespace App\Models;

use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\SoftDeletes;

class MapHouse extends Model
{
    protected $table = "map_house";
    protected $primaryKey = "id";
    protected $guarded = ['id'];


}
