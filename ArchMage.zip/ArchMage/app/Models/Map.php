<?php

namespace App\Models;

use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\SoftDeletes;

class Map extends Model
{
    protected $table = "map";
    protected $primaryKey = "id";
    protected $guarded = ['id'];

    public function plate()
    {
        return $this->hasMany('App\Models\MapPlate', 'mapId', 'id');
    }

}
