<?php

namespace App\Http\Controllers\Web;

use App\Models\Map;
use App\Models\MapHouse;
use App\Models\MapPlate;
use App\Models\MapPort;
use App\Models\MapRoad;
use App\Models\UserGetPlate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

// 地图初始化相关方法
class MapController extends \App\Http\Controllers\Controller
{
    //地图元素数量
    private $mapCountArr = [
        '1'=>[
            'mapPlateCount' => 30, //地图板块数量
            'desertMaxCount' => 2, //沙漠板块最大数量
            'mapPlateCountArr' => [3,4,5,6,5,4,3],  //每列资源板块数量
            'mapHouseCountArr' => [3,4,4,5,5,6,6,7,7,6,6,5,5,4,4,3],  //每列房屋数量
            'mapRoadCountArr' => [  //每列道路数量
                [3,4,5,6,6,5,4,3],
                [4,5,6,7,6,5,4],
                [3,4,5,6,6,5,4,3],
            ],  
        ],
        '2'=>[],
    ];

    private $allNumberArr = [2,3,4,5,6,8,9,10,11,12];   //所有板块点数
    private $normalNumberArr = [2,3,4,5,9,10,11,12];    //普通频率板块点数
    private $desertRandIndexArr = [4,5,8,9,10,13,14,15,16,19,20,21,24,25];    //沙漠可防止的下标
    private $type = '1';    //地图类型
    private $errerMessages = [  //房屋创建时错误提示
        'CANNOT_BE_ADJACENT' => '房屋不能相邻!',
        'NO_ROAD' => '想建房先修路啊弟弟!',
    ];
    private $portByHousePosition = [         //相对于路的位置确定港口
        ['houseIndexX'=>0, 'houseIndexY'=>1],
        ['houseIndexX'=>0, 'houseIndexY'=>2],
        ['houseIndexX'=>1, 'houseIndexY'=>2],
        ['houseIndexX'=>1, 'houseIndexY'=>0],
        ['houseIndexX'=>2, 'houseIndexY'=>0],
        ['houseIndexX'=>3, 'houseIndexY'=>0],
        ['houseIndexX'=>5, 'houseIndexY'=>0],
        ['houseIndexX'=>6, 'houseIndexY'=>0],
        ['houseIndexX'=>7, 'houseIndexY'=>0],
        ['houseIndexX'=>8, 'houseIndexY'=>0],
        ['houseIndexX'=>9, 'houseIndexY'=>0],
        ['houseIndexX'=>10, 'houseIndexY'=>0],
        ['houseIndexX'=>12, 'houseIndexY'=>0],
        ['houseIndexX'=>13, 'houseIndexY'=>0],
        ['houseIndexX'=>14, 'houseIndexY'=>0],
        ['houseIndexX'=>15, 'houseIndexY'=>0],
        ['houseIndexX'=>14, 'houseIndexY'=>1],
        ['houseIndexX'=>15, 'houseIndexY'=>1],
        ['houseIndexX'=>14, 'houseIndexY'=>3],
        ['houseIndexX'=>13, 'houseIndexY'=>3],
        ['houseIndexX'=>12, 'houseIndexY'=>4],
        ['houseIndexX'=>10, 'houseIndexY'=>5],
        ['houseIndexX'=>9, 'houseIndexY'=>5],
        ['houseIndexX'=>8, 'houseIndexY'=>6],
        ['houseIndexX'=>7, 'houseIndexY'=>6],
        ['houseIndexX'=>6, 'houseIndexY'=>5],
        ['houseIndexX'=>5, 'houseIndexY'=>5],
        ['houseIndexX'=>3, 'houseIndexY'=>4],
        ['houseIndexX'=>2, 'houseIndexY'=>3],
        ['houseIndexX'=>1, 'houseIndexY'=>3],
    ];

    // 重新创建地图
    public function resetMap(Request $request){
        $resourceTypeRandArr = [1,2,3,4,5]; //取随机数时的资源类型
        $resourceSumCountArr = [0,0,0,0,0,0];  //板块数量计数
        $desertIndexArr = [];  //沙漠板块下标
        $resourcePlateNumberByTypeArr = [[],[],[],[],[],[]];  //每种资源已有资源点数
        $resourcePlateNumberByCountArr = [[],[],[],[],[],[],[]]; //每一列板块已有资源点数
        $resourcePlateTypeByCountArr = [[],[],[],[],[],[],[]]; //每一列板块已有资源类型
        $resourceMaxCount = 6; //每个资源板块最大数量
        $index = 0;
        $map = null;
        DB::beginTransaction();
        try{
            //创建地图
            $map = new Map();
            $map->type = $this->type;
            $map->peopleCount = 10;
            $map->gameSequence = '';
            $map->score = 10;
            $map->save();

            //获取沙漠板块下标
            $desertIndexArr = $this->getDesertIndexArr($this->mapCountArr[$this->type]['desertMaxCount']);

            // 创建资源板块
            foreach($this->mapCountArr[$this->type]['mapPlateCountArr'] as $key=>$count){
                for($i=0; $i<$count; $i++){
                    // 从 取随机数时的资源类型 中去除已经到达资源上限的编号
                    foreach($resourceSumCountArr as $k=>$sum){
                        if($sum >= $resourceMaxCount){
                            $resourceTypeRandArr = array_diff($resourceTypeRandArr, [$k]);
                        }
                        if(count($resourceTypeRandArr) === 2){
                            $resourceMaxCount = 5;
                        }
                    }
                    $mapPlate = new MapPlate();
                    $mapPlate->mapId = $map->id;    // 注：多个地图同时创建时，id可能会有问题。
                    $mapPlate->resourcesType = $this->getPlate($resourceTypeRandArr,$desertIndexArr,$index,$key,$i,$resourcePlateTypeByCountArr);
                    $resourceSumCountArr[$mapPlate->resourcesType] = $resourceSumCountArr[$mapPlate->resourcesType]+1;
                    $mapPlate->plateType = $mapPlate->resourcesType;
                    if($mapPlate->plateType !== 0){
                        $mapPlate->plateType = 1;
                    }
                    $mapPlate->number = $this->getPlateNumber($resourcePlateNumberByTypeArr,$mapPlate->resourcesType,
                        $resourcePlateNumberByCountArr,$key,$i);
                    $mapPlate->arrIndexX = $key;
                    $mapPlate->arrIndexY = $i;
                    $mapPlate->save();

                    array_push($resourcePlateNumberByTypeArr[$mapPlate->resourcesType],$mapPlate->number);
                    array_push($resourcePlateNumberByCountArr[$key],$mapPlate->number);
                    array_push($resourcePlateTypeByCountArr[$key],$mapPlate->resourcesType);
                    $index++;
                }
            }

            // 创建港口
            $this->createMapPort($map->id);
            // 创建房屋
            $this->createMapHouse($map->id);
            // 创建道路
            $this->createMapRoad($map->id);

            DB::commit();
            return ['mapId'=>$map->id];
        }catch(\PDOException $e){
            Log::error($e);
            DB::rollBack();
            return $e;
        }
    }

    // 获取并格式化资源板块信息
    public function getMapPlateList(Request $request){
        $mapId = $request->get('mapId');
        $index = 0;
        $plateList = [[],[],[],[],[],[],[]];
        $models = MapPlate::where('mapId',$mapId)->where('plateType','!=',2)->orderBy('id')->get();
        foreach($this->mapCountArr[$this->type]['mapPlateCountArr'] as $key=>$count){
            for($i=0; $i<$count; $i++){
                array_push($plateList[$key],$models[$index]);
                $index++;
            }
        }
        $portList = $this->getMapPortList($mapId);
        $houseList = $this->getMapHouseList($mapId);
        $roadList = $this->getMapRoadList($mapId);

        return ['plateList'=>$plateList,'houseList'=>$houseList,'roadList'=>$roadList,'portList'=>$portList];
    }

    // 创建一个新房子
    public function createNewHouse(Request $request){
        $userId = $request->get('userId');;
        $house = $request->get('house');
        // 检查所选房子是否可以创建
        $errMsg = $this->checkCreateHouse($house,$userId);
        DB::beginTransaction();
        try{
            if($errMsg === ''){
                MapHouse::where('id',$house['id'])->update(['userId'=>$userId,'color'=>'black']);
                $house['userId'] = $userId;
                $house['color'] = 'black';
                // 获得资源、港口使用权
                $this->userGetNewResource($house,$userId);
            }
            DB::commit();
        }catch(\PDOException $e){
            Log::error($e);
            DB::rollBack();
            return $e;
        }
        return ['house'=>$house,'errMsg'=>$errMsg];
    }

    // 创建一条新道路
    public function createNewRoad(Request $request){
        $errMsg = '';
        $userId = $request->get('userId');
        $road = $request->get('road');
        // 检查所选道路是否可以创建
        $errMsg = $this->checkCreateRoad($road,$userId);
        if($errMsg == ''){
            DB::beginTransaction();
            try{
                MapRoad::where('id',$road['id'])->update(['userId'=>$userId,'color'=>'red']);
                $road['userId'] = $userId;
                $road['color'] = 'red';
                DB::commit();
            }catch(\PDOException $e){
                Log::error($e);
                DB::rollBack();
                return $e;
            }
        }
        return ['road'=>$road,'errMsg'=>$errMsg];
    }

    /**************************************************** 内部私有方法 ****************************************************/

    /************************** 板块方法 **************************/

    // 获取板块资源类型
    private function getPlate($resourceTypeRandArr,$desertIndexArr,$index,$key,$i,$resourcePlateTypeByCountArr){
        $type = 0;
        $count = 0; //循环计数器，超过10次就跳出循环
        $flag = true;
        if(!in_array($index, $desertIndexArr)){  //非沙漠的其他资源板块
            while($flag){
                $typeTmp = $resourceTypeRandArr[array_rand($resourceTypeRandArr,1)];
                if($count > 10){
                    $flag = false;
                    $type = $typeTmp;
                }
                $count++;
                // 向上取整
                $indexTmp = ceil(count($this->mapCountArr[$this->type]['mapPlateCountArr'])/2);
                //  新增板块不能和左侧相邻板块的点数相同
                if($key < $indexTmp){
                    if($key === 0){     //第一列
                        if($i !== 0){
                            if($resourcePlateTypeByCountArr[$key][$i-1] === $typeTmp){
                                continue;
                            }
                        }
                    }else{              //第二列到中间列
                        if($i === 0){
                            if($resourcePlateTypeByCountArr[$key-1][$i] === $typeTmp){
                                continue;
                            }
                        }elseif($i === ($this->mapCountArr[$this->type]['mapPlateCountArr'][$key]-1)){
                            if(($resourcePlateTypeByCountArr[$key][$i-1] === $typeTmp)
                                || ($resourcePlateTypeByCountArr[$key-1][$i-1] === $typeTmp)){
                                continue;
                            }
                        }else{
                            if(($resourcePlateTypeByCountArr[$key][$i-1] === $typeTmp)
                                || ($resourcePlateTypeByCountArr[$key-1][$i-1] === $typeTmp) 
                                || ($resourcePlateTypeByCountArr[$key-1][$i] === $typeTmp)){
                                continue;
                            }
                        }
                    }
                }else{
                    if($i === 0){
                        if(($resourcePlateTypeByCountArr[$key-1][$i] === $typeTmp)
                            || ($resourcePlateTypeByCountArr[$key-1][$i+1] === $typeTmp)){
                            continue;
                        }
                    }else{
                        if(($resourcePlateTypeByCountArr[$key][$i-1] === $typeTmp)
                            || ($resourcePlateTypeByCountArr[$key-1][$i] === $typeTmp) 
                            || ($resourcePlateTypeByCountArr[$key-1][$i+1] === $typeTmp)){
                            continue;
                        }
                    }
                }
                $flag = false;
                $type = $typeTmp;
            }
        }
        return $type;
    }

    // 获取板块点数
    private function getPlateNumber($resourcePlateNumberByTypeArr,$resourcesType,
        $resourcePlateNumberByCountArr,$key,$i){
        $number = 0;
        $count = 0; //循环计数器，超过20次就跳出循环
        if($resourcesType === 0){
            $number = 7;
        }else{
            $flag = true;
            $numberTmp = 0;
            $randArr = $this->allNumberArr;
            $resourcePlateNumber = $resourcePlateNumberByTypeArr[$resourcesType];
            // 一种资源的点数不能同时包含6和8
            if(in_array(6,$resourcePlateNumber) || in_array(8,$resourcePlateNumber)){
                $randArr = $this->normalNumberArr;
            }
            while($flag){
                $numberTmp = $randArr[array_rand($randArr,1)];
                if($count > 20){
                    $number = $numberTmp;
                    $flag = false;
                }
                $count++;
                // 防止一种资源点数整体偏大或偏小
                if(in_array($numberTmp,$resourcePlateNumber) 
                    || (in_array(2,$resourcePlateNumber) && $numberTmp === 3)
                    || (in_array(3,$resourcePlateNumber) && $numberTmp === 2)
                    || (in_array(2,$resourcePlateNumber) && $numberTmp === 12)
                    || (in_array(12,$resourcePlateNumber) && $numberTmp === 2)
                    || (in_array(12,$resourcePlateNumber) && $numberTmp === 11)
                    || (in_array(11,$resourcePlateNumber) && $numberTmp === 12)){
                    continue;
                }
                // 新增板块不能和上面板块的点数相同
                if($i > 0 && $resourcePlateNumberByCountArr[$key][$i-1] === $numberTmp){
                    continue;
                }
                // 向上取整
                $indexTmp = ceil(count($this->mapCountArr[$this->type]['mapPlateCountArr'])/2);
                //  新增板块不能和左侧相邻板块的点数相同
                if($key < $indexTmp){
                    if($key === 0){     //第一列
                        if($i !== 0){
                            if($resourcePlateNumberByCountArr[$key][$i-1] === $numberTmp){
                                continue;
                            }
                            // 6和8不能相邻
                            if($numberTmp == 6 && $resourcePlateNumberByCountArr[$key][$i-1] == 8
                                || $numberTmp == 8 && $resourcePlateNumberByCountArr[$key][$i-1] == 6){
                                continue;
                            }
                        }
                    }else{              //第二列到中间列
                        if($i === 0){
                            if($resourcePlateNumberByCountArr[$key-1][$i] === $numberTmp){
                                continue;
                            }
                            if($numberTmp == 6 && $resourcePlateNumberByCountArr[$key-1][$i] == 8
                                || $numberTmp == 8 && $resourcePlateNumberByCountArr[$key-1][$i] == 6){
                                continue;
                            }
                        }elseif($i === ($this->mapCountArr[$this->type]['mapPlateCountArr'][$key]-1)){
                            if(($resourcePlateNumberByCountArr[$key][$i-1] === $numberTmp)
                                || ($resourcePlateNumberByCountArr[$key-1][$i-1] === $numberTmp)){
                                continue;
                            }
                            if($numberTmp == 6 && $resourcePlateNumberByCountArr[$key][$i-1] == 8
                                || $numberTmp == 8 && $resourcePlateNumberByCountArr[$key][$i-1] == 6
                                || $numberTmp == 6 && $resourcePlateNumberByCountArr[$key-1][$i-1] == 8
                                || $numberTmp == 8 && $resourcePlateNumberByCountArr[$key-1][$i-1] == 6){
                                continue;
                            }
                        }else{
                            if(($resourcePlateNumberByCountArr[$key][$i-1] === $numberTmp)
                                || ($resourcePlateNumberByCountArr[$key-1][$i-1] === $numberTmp) 
                                || ($resourcePlateNumberByCountArr[$key-1][$i] === $numberTmp)){
                                continue;
                            }
                            if($numberTmp == 6 && $resourcePlateNumberByCountArr[$key][$i-1] == 8
                                || $numberTmp == 8 && $resourcePlateNumberByCountArr[$key][$i-1] == 6
                                || $numberTmp == 6 && $resourcePlateNumberByCountArr[$key-1][$i-1] == 8
                                || $numberTmp == 8 && $resourcePlateNumberByCountArr[$key-1][$i-1] == 6
                                || $numberTmp == 6 && $resourcePlateNumberByCountArr[$key-1][$i] == 8
                                || $numberTmp == 8 && $resourcePlateNumberByCountArr[$key-1][$i] == 6){
                                continue;
                            }
                        }
                    }
                }else{
                    if($i === 0){
                        if(($resourcePlateNumberByCountArr[$key-1][$i] === $numberTmp)
                            || ($resourcePlateNumberByCountArr[$key-1][$i+1] === $numberTmp)){
                            continue;
                        }
                        if($numberTmp == 6 && $resourcePlateNumberByCountArr[$key-1][$i] == 8
                            || $numberTmp == 8 && $resourcePlateNumberByCountArr[$key-1][$i] == 6
                            || $numberTmp == 6 && $resourcePlateNumberByCountArr[$key-1][$i+1] == 8
                            || $numberTmp == 8 && $resourcePlateNumberByCountArr[$key-1][$i+1] == 6){
                            continue;
                        }
                    }else{
                        if(($resourcePlateNumberByCountArr[$key][$i-1] === $numberTmp)
                            || ($resourcePlateNumberByCountArr[$key-1][$i] === $numberTmp) 
                            || ($resourcePlateNumberByCountArr[$key-1][$i+1] === $numberTmp)){
                            continue;
                        }
                        if($numberTmp == 6 && $resourcePlateNumberByCountArr[$key][$i-1] == 8
                            || $numberTmp == 8 && $resourcePlateNumberByCountArr[$key][$i-1] == 6
                            || $numberTmp == 6 && $resourcePlateNumberByCountArr[$key-1][$i] == 8
                            || $numberTmp == 8 && $resourcePlateNumberByCountArr[$key-1][$i] == 6
                            || $numberTmp == 6 && $resourcePlateNumberByCountArr[$key-1][$i+1] == 8
                            || $numberTmp == 8 && $resourcePlateNumberByCountArr[$key-1][$i+1] == 6){
                            continue;
                        }
                    }
                }
                $number = $numberTmp;
                $flag = false;
            }
            
            
        }
        return $number;
    }

    // 获取沙漠板块下标
    private function getDesertIndexArr($desertMaxCount){
        $keyTmp = 0;
        $i = 0;
        $countSum = 0;
        $desertIndexArr = [];
        $desertRandArrTmp = $this->desertRandIndexArr;
        $desertIndex0 = $desertRandArrTmp[array_rand($desertRandArrTmp,1)];
        array_push($desertIndexArr,$desertIndex0);

        foreach($this->mapCountArr[$this->type]['mapPlateCountArr'] as $key=>$count){
            $countSum = $countSum + $count;
            if($countSum > $desertIndex0){
                $keyTmp = $key;
                break;
            }
        }
        // 向下取整
        $indexTmp = floor(count($this->mapCountArr[$this->type]['mapPlateCountArr'])/2);    // $indexTmp = 3
        $desertRandArrTmp = array_diff($desertRandArrTmp, [$desertIndex0]);
        $desertRandArrTmp = array_diff($desertRandArrTmp, [$desertIndex0-1]);
        $desertRandArrTmp = array_diff($desertRandArrTmp, [$desertIndex0+1]);
        if($keyTmp < $indexTmp){
            $desertRandArrTmp = array_diff($desertRandArrTmp, [$desertIndex0 - $this->mapCountArr[$this->type]['mapPlateCountArr'][$keyTmp-1]]);
            $desertRandArrTmp = array_diff($desertRandArrTmp, [$desertIndex0 - ($this->mapCountArr[$this->type]['mapPlateCountArr'][$keyTmp-1] + 1)]);
            $desertRandArrTmp = array_diff($desertRandArrTmp, [$desertIndex0 + $this->mapCountArr[$this->type]['mapPlateCountArr'][$keyTmp]]);
            $desertRandArrTmp = array_diff($desertRandArrTmp, [$desertIndex0 + ($this->mapCountArr[$this->type]['mapPlateCountArr'][$keyTmp] + 1)]);
        }elseif($keyTmp == $indexTmp){
            $desertRandArrTmp = array_diff($desertRandArrTmp, [$desertIndex0 - $this->mapCountArr[$this->type]['mapPlateCountArr'][$keyTmp-1]]);
            $desertRandArrTmp = array_diff($desertRandArrTmp, [$desertIndex0 - ($this->mapCountArr[$this->type]['mapPlateCountArr'][$keyTmp-1] + 1)]);
            $desertRandArrTmp = array_diff($desertRandArrTmp, [$desertIndex0 + $this->mapCountArr[$this->type]['mapPlateCountArr'][$keyTmp]]);
            $desertRandArrTmp = array_diff($desertRandArrTmp, [$desertIndex0 + ($this->mapCountArr[$this->type]['mapPlateCountArr'][$keyTmp] - 1)]);
        }else{
            $desertRandArrTmp = array_diff($desertRandArrTmp, [$desertIndex0 - $this->mapCountArr[$this->type]['mapPlateCountArr'][$keyTmp-1]]);
            $desertRandArrTmp = array_diff($desertRandArrTmp, [$desertIndex0 - ($this->mapCountArr[$this->type]['mapPlateCountArr'][$keyTmp-1] - 1)]);
            $desertRandArrTmp = array_diff($desertRandArrTmp, [$desertIndex0 + $this->mapCountArr[$this->type]['mapPlateCountArr'][$keyTmp]]);
            $desertRandArrTmp = array_diff($desertRandArrTmp, [$desertIndex0 + ($this->mapCountArr[$this->type]['mapPlateCountArr'][$keyTmp] - 1)]);
        }
        $desertIndex1 = $desertRandArrTmp[array_rand($desertRandArrTmp,1)];
        array_push($desertIndexArr,$desertIndex1);
        return $desertIndexArr;
    }

    /************************** 房屋方法 **************************/

    // 创建房屋
    private function createMapHouse($mapId){
        foreach($this->mapCountArr[$this->type]['mapHouseCountArr'] as $key=>$count){
            for($i=0; $i<$count; $i++){
                $mapHouse = new MapHouse();
                $mapHouse->mapId = $mapId;
                $mapHouse->userId = 0;
                $mapHouse->type = 1;
                $mapHouse->resourcesNumber = 1;
                $mapHouse->color = 'black';
                $mapHouse->arrIndexX = $key;
                $mapHouse->arrIndexY = $i;
                $mapHouse->nearPortId = 0;
                $mapHouse->save();
            }
        }
    }

    // 获取房屋
    private function getMapHouseList($mapId){
        $index = 0;
        $houseList = [];
        $models = MapHouse::where('mapId',$mapId)->orderBy('id')->get();
        foreach($this->mapCountArr[$this->type]['mapHouseCountArr'] as $key=>$count){
            $arrTmp = [];
            for($i=0; $i<$count; $i++){
                array_push($arrTmp,$models[$index]);
                $index++;
            }
            $houseList[] = $arrTmp;
        }
        return $houseList;
    }

    // 检查所选房子是否可以创建
    private function checkCreateHouse($house,$userId){
        $errMsg = '';
        $flag = false;
        $key = $house['arrIndexX'];
        $index = $house['arrIndexY'];
        $selfBuiltRoadCount = MapRoad::where('mapId',$house['mapId'])->where('userId',$userId)->count();
        $selfBuiltHouseCount = MapHouse::where('mapId',$house['mapId'])->where('userId',$userId)->count();
        $builtHouseList = MapHouse::where('mapId',$house['mapId'])->where('userId','!=',0)->get();
        $builtRoadList = MapRoad::where('mapId',$house['mapId'])->where('userId','!=',0)->get();
        $houseArrMiddleCount = floor(count($this->mapCountArr[$this->type]['mapHouseCountArr']) / 2);
        // 验证相邻格子不能有房子
        foreach($builtHouseList as $builtHouse){
            if($key % 2 == 0){
                if($key - 1 >= 0){
                    if($key - 1 == $builtHouse['arrIndexX'] && $index == $builtHouse['arrIndexY']){
                        $errMsg = $this->errerMessages['CANNOT_BE_ADJACENT'];
                    }
                }
                if($key < $houseArrMiddleCount){
                    if($key + 1 == $builtHouse['arrIndexX'] && 
                    ($index == $builtHouse['arrIndexY'] || $index + 1 == $builtHouse['arrIndexY'])){
                        $errMsg = $this->errerMessages['CANNOT_BE_ADJACENT'];
                    }
                }else{
                    if($index - 1 >= 0){
                        if($key + 1 == $builtHouse['arrIndexX'] && $index - 1 == $builtHouse['arrIndexY']){
                            $errMsg = $this->errerMessages['CANNOT_BE_ADJACENT'];
                        }
                    }
                    if($key + 1 == $builtHouse['arrIndexX'] && $index == $builtHouse['arrIndexY']){
                        $errMsg = $this->errerMessages['CANNOT_BE_ADJACENT'];
                    }
                }
            }else{
                if($key < $houseArrMiddleCount){
                    if($index - 1 >= 0){
                        if($key - 1 == $builtHouse['arrIndexX'] && $index - 1 == $builtHouse['arrIndexY']){
                            $errMsg = $this->errerMessages['CANNOT_BE_ADJACENT'];
                        }
                    }
                    if($key - 1 == $builtHouse['arrIndexX'] && $index == $builtHouse['arrIndexY']){
                        $errMsg = $this->errerMessages['CANNOT_BE_ADJACENT'];
                    }
                    if($key + 1 == $builtHouse['arrIndexX'] && $index == $builtHouse['arrIndexY']){
                        $errMsg = $this->errerMessages['CANNOT_BE_ADJACENT'];
                    }
                }else{
                    if($key + 1 <= count($this->mapCountArr[$this->type]['mapHouseCountArr']) - 1){
                        if($key + 1 == $builtHouse['arrIndexX'] && $index == $builtHouse['arrIndexY']){
                            $errMsg = $this->errerMessages['CANNOT_BE_ADJACENT'];
                        }
                    }
                    if($key - 1 == $builtHouse['arrIndexX'] && 
                    ($index == $builtHouse['arrIndexY'] || $index + 1 == $builtHouse['arrIndexY'])){
                        $errMsg = $this->errerMessages['CANNOT_BE_ADJACENT'];
                    }
                }
            }
        }
        // 前两个房子是先建房再修路
        if($selfBuiltHouseCount > 2){
            // 验证房屋旁边需要有道路
            foreach($builtRoadList as $builtRoad){
                $lineKey = floor($key / 2);    // 房屋相对与路的下标
                if($key % 2 == 0){
                    if($lineKey- 1 >= 0){
                        if($builtRoad['type'] == 1 && $lineKey - 1 == $builtRoad['arrIndexX'] && $index == $builtRoad['arrIndexY']){
                            $flag = true;
                            break;
                        }
                    }
                    if($lineKey < 4){
                        if($lineKey == $builtRoad['arrIndexX'] && 
                        (($builtRoad['type'] == 0 && $index == $builtRoad['arrIndexY']) || ($builtRoad['type'] == 2 && $index == $builtRoad['arrIndexY']))){
                            $flag = true;
                            break;
                        }
                    }else{
                        if($index - 1 >= 0){
                            if($builtRoad['type'] == 0 && $lineKey == $builtRoad['arrIndexX'] && $index - 1 == $builtRoad['arrIndexY']){
                                $flag = true;
                                break;
                            }
                        }
                        if($builtRoad['type'] == 2 && $lineKey == $builtRoad['arrIndexX'] && $index == $builtRoad['arrIndexY']){
                            $flag = true;
                            break;
                        }
                    }
                }else{
                    if($lineKey < 4){
                        if($index - 1 >= 0){
                            if($builtRoad['type'] == 2 && $lineKey == $builtRoad['arrIndexX'] && $index - 1 == $builtRoad['arrIndexY']){
                                $flag = true;
                                break;
                            }
                        }
                        if($builtRoad['type'] == 0 && $lineKey == $builtRoad['arrIndexX'] && $index == $builtRoad['arrIndexY']){
                            $flag = true;
                            break;
                        }
                        if($builtRoad['type'] == 1 && $lineKey == $builtRoad['arrIndexX'] && $index == $builtRoad['arrIndexY']){
                            $flag = true;
                            break;
                        }
                    }else{
                        if($lineKey < $houseArrMiddleCount - 1){
                            if($builtRoad['type'] == 1 && $lineKey == $builtRoad['arrIndexX'] && $index == $builtRoad['arrIndexY']){
                                $flag = true;
                                break;
                            }
                        }
                        if($lineKey == $builtRoad['arrIndexX'] && 
                        (($builtRoad['type'] == 0 && $index == $builtRoad['arrIndexY']) || ($builtRoad['type'] == 1 && $index == $builtRoad['arrIndexY']))){
                            $flag = true;
                            break;
                        }
                    }
                }
            }
        }else{
            if($selfBuiltHouseCount > $selfBuiltRoadCount){
                $errMsg = "开局创建房屋后需要再建一条道路!";
            }
        }
        if(!$flag){
            $errMsg = $this->errerMessages['NO_ROAD'];
        }
        return $errMsg;
    }

    /************************** 道路方法 **************************/

    // 创建道路、创建岛屿（岛屿与道路关联）
    private function createMapRoad($mapId){
        foreach($this->mapCountArr[$this->type]['mapRoadCountArr'] as $type=>$arr){
            foreach($arr as $key=>$count){
                for($i=0; $i<$count; $i++){
                    $mapHouse = new MapRoad();
                    $mapHouse->mapId = $mapId;
                    $mapHouse->userId = 0;
                    $mapHouse->color = 'red';
                    $mapHouse->type = $type;
                    $mapHouse->arrIndexX = $key;
                    $mapHouse->arrIndexY = $i;
                    $mapHouse->save();
                }
            }
        }
    }

    // 获取道路
    private function getMapRoadList($mapId){
        $index = 0;
        $roadList = [];
        $models = MapRoad::where('mapId',$mapId)->orderBy('id')->get();
        foreach($this->mapCountArr[$this->type]['mapRoadCountArr'] as $type=>$arr){
            $typeArrTmp = [];
            foreach($arr as $key=>$count){
                $countArrTmp = [];
                for($i=0; $i<$count; $i++){
                    array_push($countArrTmp,$models[$index]);
                    $index++;
                }
                $typeArrTmp[] = $countArrTmp;
            }
            $roadList[] = $typeArrTmp;
        }
        return $roadList;
    }

    // 检查所选道路是否可以创建
    private function checkCreateRoad($road,$userId){
        $errMsg = '新建的桥必须与自己其他桥相连!';
        $type = $road['type'];
        $key = $road['arrIndexX'];
        $index = $road['arrIndexY'];
        $selfBuiltRoadCount = MapRoad::where('mapId',$road['mapId'])->where('userId',$userId)->count();
        $selfBuiltHouseList = MapHouse::where('mapId',$road['mapId'])->where('userId',$userId)->get();
        $builtRoadList = MapRoad::where('mapId',$road['mapId'])->where('userId','!=',0)->get();
        // 前两条路需要建在房屋旁边
        if($selfBuiltRoadCount > 2){
            // 验证新建道路旁边需要有道路
            foreach($builtRoadList as $builtRoad){
                $midCount = floor(count($this->mapCountArr[$this->type]['mapRoadCountArr'][$type]) / 2);
                switch($type){
                    case 0:
                        // 左上 \
                        if($key < $midCount){
                            if($builtRoad['type'] == 2 && $key == $builtRoad['arrIndexX'] && $index - 1 == $builtRoad['arrIndexY']){
                                $errMsg = '';
                                break;
                            }
                        }else{
                            if($builtRoad['type'] == 2 && $key == $builtRoad['arrIndexX'] && $index == $builtRoad['arrIndexY']){
                                $errMsg = '';
                                break;
                            }
                        }
                        // 右上 ——
                        if($builtRoad['type'] == 1 && $key == $builtRoad['arrIndexX'] && $index == $builtRoad['arrIndexY']){
                            $errMsg = '';
                            break;
                        }
                        // 左下 ——
                        if($key < $midCount){
                            if($builtRoad['type'] == 1 && $key - 1 == $builtRoad['arrIndexX'] && $index == $builtRoad['arrIndexY']){
                                $errMsg = '';
                                break;
                            }
                        }else{
                            if($builtRoad['type'] == 1 && $key - 1 == $builtRoad['arrIndexX'] && $index + 1 == $builtRoad['arrIndexY']){
                                $errMsg = '';
                                break;
                            }
                        }
                        // 右下 \
                        if($key < $midCount){
                            if($builtRoad['type'] == 2 && $key == $builtRoad['arrIndexX'] && $index == $builtRoad['arrIndexY']){
                                $errMsg = '';
                                break;
                            }
                        }else{
                            if($builtRoad['type'] == 2 && $key == $builtRoad['arrIndexX'] && $index + 1 == $builtRoad['arrIndexY']){
                                $errMsg = '';
                                break;
                            }
                        }
                        break;
                    case 1:
                        // 左上 \
                        if($key <= $midCount){
                            if($builtRoad['type'] == 2 && $key == $builtRoad['arrIndexX'] && $index - 1 == $builtRoad['arrIndexY']){
                                $errMsg = '';
                                break;
                            }
                        }else{
                            if($builtRoad['type'] == 2 && $key == $builtRoad['arrIndexX'] && $index == $builtRoad['arrIndexY']){
                                $errMsg = '';
                                break;
                            }
                        }
                        // 右上 /
                        if($key < $midCount){
                            if($builtRoad['type'] == 0 && $key + 1 == $builtRoad['arrIndexX'] && $index == $builtRoad['arrIndexY']){
                                $errMsg = '';
                                break;
                            }
                        }else{
                            if($builtRoad['type'] == 0 && $key + 1 == $builtRoad['arrIndexX'] && $index - 1 == $builtRoad['arrIndexY']){
                                $errMsg = '';
                                break;
                            }
                        }
                        // 左下 /
                        if($builtRoad['type'] == 0 && $key == $builtRoad['arrIndexX'] && $index == $builtRoad['arrIndexY']){
                            $errMsg = '';
                            break;
                        }
                        // 右下 \
                        if($builtRoad['type'] == 2 && $key + 1 == $builtRoad['arrIndexX'] && $index == $builtRoad['arrIndexY']){
                            $errMsg = '';
                            break;
                        }
                        break;
                    case 2:
                        // 左上 ——
                        if($builtRoad['type'] == 1 && $key - 1 == $builtRoad['arrIndexX'] && $index == $builtRoad['arrIndexY']){
                            $errMsg = '';
                            break;
                        }
                        // 右上 /
                        if($key < $midCount){
                            if($builtRoad['type'] == 0 && $key == $builtRoad['arrIndexX'] && $index == $builtRoad['arrIndexY']){
                                $errMsg = '';
                                break;
                            }
                        }else{
                            if($builtRoad['type'] == 0 && $key == $builtRoad['arrIndexX'] && $index - 1 == $builtRoad['arrIndexY']){
                                $errMsg = '';
                                break;
                            }
                        }
                        // 左下 /
                        if($key < $midCount){
                            if($builtRoad['type'] == 0 && $key == $builtRoad['arrIndexX'] && $index + 1 == $builtRoad['arrIndexY']){
                                $errMsg = '';
                                break;
                            }
                        }else{
                            if($builtRoad['type'] == 0 && $key == $builtRoad['arrIndexX'] && $index == $builtRoad['arrIndexY']){
                                $errMsg = '';
                                break;
                            }
                        }
                        // 右下 ——
                        if($key < $midCount){
                            if($builtRoad['type'] == 1 && $key == $builtRoad['arrIndexX'] && $index + 1 == $builtRoad['arrIndexY']){
                                $errMsg = '';
                                break;
                            }
                        }else{
                            if($builtRoad['type'] == 1 && $key == $builtRoad['arrIndexX'] && $index == $builtRoad['arrIndexY']){
                                $errMsg = '';
                                break;
                            }
                        }
                        break;
                    default:
                        $errMsg = '你建的这桥的类型有问题啊!(type=)' . $type;
                }
            }
        }else{
            if($selfBuiltRoadCount >= count($selfBuiltHouseList)){
                $errMsg = '开局的两个房子请先建房子再修路!';
            }else{
                foreach($selfBuiltHouseList as $key=>$house){
                    switch($type){
                        //TODO 开局一个房子一条路
                        case 0:
                            // if(){

                            // }
                            break;
                        case 1:
                            break;
                        case 2:
                            break;
                        default:
                            $errMsg = '你建的这桥的类型有问题啊!(type=)' . $type;
                    }
                }
            }
        }
        return $errMsg;
    }

    /************************** 资源方法 **************************/

    // 建房后获取对应板块资源权限
    private function userGetNewResource($house,$userId){
        $plateKey = floor($house['arrIndexX'] / 2);
        $index = $house['arrIndexY'];
        $plateTmpArr = [];
        // 获得资源板块
        if($house['arrIndexX'] % 2 == 0){
            $plateTmp1 = MapPlate::where('mapId',$house['mapId'])->where('arrIndexX',$plateKey-1)->where('arrIndexY',$index-1)->first();
            $plateTmp2 = MapPlate::where('mapId',$house['mapId'])->where('arrIndexX',$plateKey-1)->where('arrIndexY',$index)->first();
            $plateTmp3 = MapPlate::where('mapId',$house['mapId'])->where('arrIndexX',$plateKey)->where('arrIndexY',$index)->first();
            $plateTmpArr[] = $plateTmp1;
            $plateTmpArr[] = $plateTmp2;
            $plateTmpArr[] = $plateTmp3;
            $this->saveUserGetPlateModel($plateTmpArr,$house,$userId);
        }else{
            $plateTmp1 = MapPlate::where('mapId',$house['mapId'])->where('arrIndexX',$plateKey-1)->where('arrIndexY',$index-1)->first();
            $plateTmp2 = MapPlate::where('mapId',$house['mapId'])->where('arrIndexX',$plateKey)->where('arrIndexY',$index-1)->first();
            $plateTmp3 = MapPlate::where('mapId',$house['mapId'])->where('arrIndexX',$plateKey)->where('arrIndexY',$index)->first();
            $plateTmpArr[] = $plateTmp1;
            $plateTmpArr[] = $plateTmp2;
            $plateTmpArr[] = $plateTmp3;
            $this->saveUserGetPlateModel($plateTmpArr,$house,$userId);
        }
        // 获得港口
        if($house['nearPortId'] != 0){
            $port = MapPort::where('id',$house['nearPortId'])->first();
            if($port){
                $userGetPlate = new UserGetPlate();
                $userGetPlate->mapId = $house['mapId'];
                $userGetPlate->houseId = $house['id'];
                $userGetPlate->userId = $userId;
                $userGetPlate->plateId = 0;
                $userGetPlate->resourcesType = $port['resourcesType'];
                $userGetPlate->plateType = 2;
                $userGetPlate->number = 0;
                $userGetPlate->haveRobber = 0;
                $userGetPlate->resourcesCount = $port['resourcesNumber'];
                $userGetPlate->save();
            }
        }
    }

    // 用户已有资源入库
    private function saveUserGetPlateModel($plateArr,$house,$userId){
        foreach($plateArr as $plate){
            if($plate && $plate['plateType'] != 0){
                $userGetPlate = new UserGetPlate();
                $userGetPlate->mapId = $house['mapId'];
                $userGetPlate->houseId = $house['id'];
                $userGetPlate->userId = $userId;
                $userGetPlate->plateId = $plate['id'];
                $userGetPlate->resourcesType = $plate['resourcesType'];
                $userGetPlate->plateType = $plate['plateType'];
                $userGetPlate->number = $plate['number'];
                $userGetPlate->haveRobber = 0;
                $userGetPlate->resourcesCount = 1;
                $userGetPlate->save();
            }
        }
    }

    /************************** 港口方法 **************************/
    // 创建港口
    private function createMapPort($mapId){
        $portTypeCountArr = [0,0,0,0,0,0]; //每一种资源港口数
        $allPort = []; //所有港口类型
        $resourceTypeRandArr = [1,2,3,4,5]; //取随机数时的资源类型
        for($i = 0; $i < 10; $i++){
            $index = 0; //超过10次跳出循环
            $flag = true;
            $mapPort = new MapPort();
            $mapPort->mapId = $mapId;
            $mapPort->userId = 0;
            $mapPort->resourcesNumber = 2;
            while($flag){
                $typeTmp = $resourceTypeRandArr[array_rand($resourceTypeRandArr,1)];
                if($index > 10){
                    $mapPort->resourcesType = $typeTmp;
                    break;
                }
                $index++;
                if($portTypeCountArr[$typeTmp] >= 2){
                    continue;
                }
                if($i > 0){
                    if($typeTmp == $allPort[$i - 1]){
                        continue;
                    }
                }
                $mapPort->resourcesType = $typeTmp;
                $flag = false;
            }
            array_push($allPort,$mapPort->resourcesType);
            $portTypeCountArr[$mapPort->resourcesType] = $portTypeCountArr[$mapPort->resourcesType] + 1;
            if($portTypeCountArr[$mapPort->resourcesType] == 2){
                $resourceTypeRandArr = array_diff($resourceTypeRandArr, [$mapPort->resourcesType]);
            }
            $mapPort->save();
        }
    }

    // 获取港口
    private function getMapPortList($mapId){
        $index = -1;
        $portList = MapPort::where('mapId',$mapId)->get();
        DB::beginTransaction();
        try{
            foreach($this->portByHousePosition as $key=>$portPosition){
                if($key % 3 == 0){
                    $index = $index + 1;
                }
                MapHouse::where('mapId',$mapId)->where('arrIndexX',$portPosition['houseIndexX'])
                    ->where('arrIndexY',$portPosition['houseIndexY'])->update(['nearPortId'=>$portList[$index]['id']]);
            }
            DB::commit();
        }catch(\PDOException $e){
            Log::error($e);
            DB::rollBack();
        }
        return $portList;
    }
}
