<?php

namespace App\Http\Controllers\Web;

use App\Models\Map;
use App\Models\MapHouse;
use App\Models\MapPlate;
use App\Models\MapPort;
use App\Models\MapRoad;
use App\Models\UserGetPlate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

//  游戏中操作相关方法
class ActionController extends \App\Http\Controllers\Controller
{
    // 获取所有用户资源
    public function getUserResources(Request $request){
        
    }
}